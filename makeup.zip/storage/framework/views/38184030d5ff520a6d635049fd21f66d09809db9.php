<aside id="colorlib-aside" role="complementary" class="js-fullheight text-center">
    <h1 id="colorlib-logo">
        <a href="<?php echo e(route('front.home')); ?>">
        <img style="max-width:110%" class="img-fluid rounded" src="<?php echo e(url('/skins/front/images/logo/logo.jpg')); ?>" alt="logo"/>
        </a>
    </h1>
    <nav id="colorlib-main-menu" role="navigation">
        <ul>
            <li><a href="<?php echo e(route('front.home')); ?>">Početna</a></li>
            <li><a href="<?php echo e(route('front.gallery')); ?>">Galerija</a></li>
            <li><a href="<?php echo e(route('front.about')); ?>">O meni</a></li>
            <li><a href="<?php echo e(route('front.contact')); ?>">Kontakt / Zakazivanje</a></li>
        </ul>
    </nav>
    <div class="colorlib-footer">
        <h3>Zaprati nas &#8659;</h3>
        <div class="d-flex justify-content-center">
            <ul class="d-flex align-items-center">
                <li class="d-flex align-items-center jusitfy-content-center">
                    <a href="https://www.facebook.com/whiterabbitmakeup/" target="_blank">
                        <i class="icon-facebook"></i>
                    </a>
                </li>
                <li class="d-flex align-items-center jusitfy-content-center">
                    <a href="https://www.instagram.com/whiterabbitmakeupns/" target="_blank">
                        <i class="icon-instagram"></i>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</aside> <!-- END COLORLIB-ASIDE --><?php /**PATH C:\Users\Nikola\Desktop\site\makeup\resources\views/front/nav.blade.php ENDPATH**/ ?>